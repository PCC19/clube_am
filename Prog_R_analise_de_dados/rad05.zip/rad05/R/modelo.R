
# Pacotes -----------------------------------------------------------------

# Carregar pacotes
library(tidyverse)
#library()



# Importação de dados -----------------------------------------------------

# Coleta de dados (offline/online)
# aqui entra o código de importação



# Tratamento de dados -----------------------------------------------------

# Rotina de tratamento de dados
# aqui entra o código de tratamento



# Visualização de dados ---------------------------------------------------

# Criação de gráficos
# aqui entra o código p/ gerar gráficos

# Criação de tabelas
# aqui entra o código p/ gerar tabelas
