
minha_funcao <-function(x) {
  ("num" %% (10 ^ n))
  %/% (10 ^(n - 1))
}}
