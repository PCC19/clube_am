
# Criação de um objeto: nome_objeto <- valor
a <- 1

# Regras de nomes para objetos

# Permitido

a <- 1
a1 <- 1
a.1 <- "a"
a_1 <- 2
a.1_b <- "b"

# Não permitido
_a <- 1
1a <- "a"
a-1 <- 0
else <- 0

# R diferencia minúsculas e maiúsculas
a <- 1
A <- 1


# Cópia e modificação
a
b <- a

b <- 2


# Classes de objetos
class(a) # obter a classe do objeto

1 + 1
"1" + "1"

w <- 1
x <- "a"
y <- TRUE
z <- NULL

class(w)
class(x)
class(y)
class(z)
